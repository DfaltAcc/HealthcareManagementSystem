import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { getToken } from "next-auth/jwt"

export async function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname

  // Define public paths that don't require authentication
  const isPublicPath = path.startsWith("/auth/") || path.startsWith("/api/auth/") || path === "/unauthorized"

  try {
    // Get the token from the request
    const token = await getToken({
      req: request,
      secret: process.env.NEXTAUTH_SECRET || "your-secret-key-here-for-development",
    })

    // If it's a public path and user is logged in, redirect to dashboard (except for API routes)
    if (isPublicPath && token && !path.startsWith("/api/auth/")) {
      return NextResponse.redirect(new URL("/", request.nextUrl))
    }

    // If it's a protected path and user is not logged in, redirect to signin
    if (!isPublicPath && !token) {
      return NextResponse.redirect(new URL("/auth/signin", request.nextUrl))
    }

    return NextResponse.next()
  } catch (error) {
    console.error("Middleware error:", error)
    // If there's an error with the token, redirect to signin for protected routes
    if (!isPublicPath) {
      return NextResponse.redirect(new URL("/auth/signin", request.nextUrl))
    }
    return NextResponse.next()
  }
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    "/((?!_next/static|_next/image|favicon.ico).*)",
  ],
}
