import type { NextAuthOptions } from "next-auth"
import Google from "next-auth/providers/google"
import Credentials from "next-auth/providers/credentials"
import { users } from "./mock-data"

export const authOptions: NextAuthOptions = {
  providers: [
    Google({
      clientId: process.env.GOOGLE_CLIENT_ID || "demo-client-id",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || "demo-client-secret",
    }),
    Credentials({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
        code: { label: "2FA Code", type: "text" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null
        }

        // Find user in mock data
        const user = users.find((u) => u.email === credentials.email)

        if (!user) {
          throw new Error("No user found with this email")
        }

        // In a real app, you'd verify the password hash
        // For demo purposes, we'll use a simple check
        const validPassword = credentials.password === "password123"

        if (!validPassword) {
          throw new Error("Invalid password")
        }

        // If 2FA code is provided, verify it (mock verification)
        if (credentials.code) {
          const validCode = credentials.code === "123456" // Mock 2FA code
          if (!validCode) {
            throw new Error("Invalid 2FA code")
          }
        }

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          image: user.avatar,
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user, account }) {
      if (user) {
        token.role = user.role
        token.id = user.id
      }

      // Handle Google OAuth
      if (account?.provider === "google") {
        // Check if Google user exists in our system
        const existingUser = users.find((u) => u.email === token.email)
        if (existingUser) {
          token.role = existingUser.role
          token.id = existingUser.id
        } else {
          // New Google user - assign default role
          token.role = "patient"
          token.id = `google-${token.sub}`
        }
      }

      return token
    },
    async session({ session, token }) {
      if (token) {
        session.user.id = token.id as string
        session.user.role = token.role as string
      }
      return session
    },
    async signIn({ user, account, profile }) {
      // Allow Google OAuth for any user
      if (account?.provider === "google") {
        return true
      }

      // For credentials, user is already validated in authorize
      return true
    },
  },
  pages: {
    signIn: "/auth/signin",
    error: "/auth/error",
  },
  session: {
    strategy: "jwt",
    maxAge: 30 * 24 * 60 * 60, // 30 days
  },
  secret: process.env.NEXTAUTH_SECRET || "fallback-secret-key-for-development",
  debug: process.env.NODE_ENV === "development",
}

// This file is kept for compatibility but the main auth config is now in the API route
export const authConfig = {
  pages: {
    signIn: "/auth/signin",
    error: "/auth/error",
  },
}
