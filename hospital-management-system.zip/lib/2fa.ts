import { authenticator } from "otplib"

// Generate a secret for 2FA
export function generate2FASecret(email: string): string {
  return authenticator.generateSecret()
}

// Generate QR code URL for 2FA setup
export function generate2FAQRCode(email: string, secret: string): string {
  const serviceName = "Hospital Management System"
  return authenticator.keyuri(email, serviceName, secret)
}

// Verify 2FA token
export function verify2FAToken(token: string, secret: string): boolean {
  try {
    return authenticator.verify({ token, secret })
  } catch (error) {
    return false
  }
}

// Generate backup codes
export function generateBackupCodes(): string[] {
  const codes = []
  for (let i = 0; i < 10; i++) {
    codes.push(Math.random().toString(36).substring(2, 10).toUpperCase())
  }
  return codes
}
