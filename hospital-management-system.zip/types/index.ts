// Core User Types
export interface User {
  id: string
  email: string
  name: string
  role: "admin" | "doctor" | "nurse" | "patient"
  avatar?: string
}

// Patient Types
export interface Patient {
  id: string
  userId?: string
  firstName: string
  lastName: string
  dateOfBirth: string
  gender: "male" | "female" | "other"
  bloodType: string
  contactNumber: string
  email: string
  address: string
  emergencyContact: {
    name: string
    relation: string
    contactNumber: string
  }
  insuranceDetails?: {
    provider: string
    policyNumber: string
    expiryDate: string
  }
  allergies: string[]
  medicalHistory: string[]
  chronicConditions: string[]
}

// Doctor Types
export interface Doctor {
  id: string
  userId: string
  firstName: string
  lastName: string
  specialization: string
  department: string
  contactNumber: string
  email: string
  licenseNumber: string
  consultationFee: number
  experience: number
  qualifications: string[]
  availability: {
    day: string
    startTime: string
    endTime: string
  }[]
}

// Appointment Types
export interface Appointment {
  id: string
  patientId: string
  doctorId: string
  date: string
  startTime: string
  endTime: string
  status: "scheduled" | "completed" | "cancelled" | "no-show"
  type: "regular" | "follow-up" | "emergency" | "consultation"
  notes?: string
  symptoms?: string[]
  priority?: "low" | "medium" | "high"
  roomNumber?: string
  fee: number
}

// Ward Types
export interface Ward {
  id: string
  name: string
  type: "general" | "icu" | "maternity" | "pediatric" | "emergency"
  floorNumber: number
  totalBeds: number
  availableBeds: number
  headNurse: string
  contactNumber: string
  amenities: string[]
}

// Medical Record Types
export interface MedicalRecord {
  id: string
  patientId: string
  doctorId: string
  date: string
  diagnosis: string
  symptoms: string[]
  treatment: string
  notes: string
  followUpRequired: boolean
  followUpDate?: string
  lastUpdated: string
  lastUpdatedBy: string
  attachments?: {
    id: string
    name: string
    url: string
    type: string
  }[]
}

// Lab Types
export interface Lab {
  id: string
  patientId: string
  medicalRecordId?: string
  doctorId: string
  testType: string
  date: string
  results?: string
  referenceRange?: {
    min: number
    max: number
    unit: string
  }
  isAbnormal?: boolean
  status: "pending" | "in-progress" | "completed" | "cancelled"
  requestedBy: string
  performedAt?: string
  priority: "routine" | "urgent" | "stat"
  cost: number
  notes?: string
}

// Medicine Types
export interface Medicine {
  id: string
  name: string
  description: string
  dosageForm: "tablet" | "capsule" | "liquid" | "injection" | "inhaler" | "cream"
  strength: string
  manufacturer: string
  availableQuantity: number
  unitPrice: number
  expiryDate: string
  batchNumber: string
  sideEffects: string[]
  contraindications: string[]
}

// Prescription Types
export interface OrderLine {
  id: string
  medicineId: string
  quantity: number
  dosage: string
  frequency: string
  duration: string
  instructions: string
}

export interface Prescription {
  id: string
  patientId: string
  doctorId: string
  medicalRecordId?: string
  date: string
  status: "active" | "completed" | "cancelled"
  orderLines: OrderLine[]
  totalCost: number
  notes?: string
  issuedAt: string
  validUntil: string
}

// Admittance Types
export interface Admittance {
  id: string
  patientId: string
  wardId: string
  bedNumber: string
  admissionDate: string
  expectedDischargeDate?: string
  actualDischargeDate?: string
  status: "admitted" | "discharged" | "transferred"
  admittingDoctor: string
  reason: string
  notes?: string
  emergencyContact: {
    name: string
    relation: string
    contactNumber: string
  }
}

// Vital Signs Types
export interface VitalSigns {
  id: string
  patientId: string
  admittanceId?: string
  recordedAt: string
  recordedBy: string
  temperature: number
  bloodPressure: {
    systolic: number
    diastolic: number
  }
  heartRate: number
  respiratoryRate: number
  oxygenSaturation: number
  bloodGlucose?: number
  notes?: string
}

// Message Types
export interface Message {
  id: string
  senderId: string
  receiverId: string
  subject: string
  content: string
  timestamp: string
  isRead: boolean
  priority: "low" | "medium" | "high"
  category: "patient_care" | "administrative" | "emergency" | "general"
}

// Notification Types
export interface Notification {
  id: string
  userId: string
  title: string
  message: string
  type: "appointment" | "lab_result" | "medication" | "emergency" | "system"
  timestamp: string
  isRead: boolean
  actionUrl?: string
}

// Insurance Types
export interface Insurance {
  id: string
  patientId: string
  provider: string
  policyNumber: string
  policyHolderName: string
  relationshipToPatient: string
  groupNumber: string
  effectiveDate: string
  expiryDate: string
  coverage: {
    type: "basic" | "comprehensive" | "premium"
    deductible: number
    copay: number
    outOfPocketMax: number
    coveragePercentage: number
  }
  isActive: boolean
}

// Billing Types
export interface BillItem {
  id: string
  description: string
  quantity: number
  unitPrice: number
  totalPrice: number
  serviceDate: string
}

export interface Bill {
  id: string
  patientId: string
  billNumber: string
  date: string
  dueDate: string
  status: "pending" | "paid" | "overdue" | "cancelled"
  items: BillItem[]
  subtotal: number
  tax: number
  insuranceCoverage: number
  patientResponsibility: number
  totalAmount: number
}

// Payment Types
export interface Payment {
  id: string
  billId: string
  patientId: string
  amount: number
  paymentMethod: "cash" | "credit_card" | "debit_card" | "insurance" | "check"
  paymentDate: string
  status: "pending" | "completed" | "failed" | "refunded"
  transactionId?: string
  cardLast4?: string
  receiptNumber: string
}

// Inventory Types
export interface InventoryItem {
  id: string
  name: string
  category: "medical_supplies" | "equipment" | "pharmaceuticals" | "office_supplies"
  currentStock: number
  minStockLevel: number
  maxStockLevel: number
  unitPrice: number
  supplier: string
  lastRestocked: string
  expiryDate?: string
  location: string
}

export interface StockMovement {
  id: string
  inventoryItemId: string
  type: "inbound" | "outbound" | "adjustment"
  quantity: number
  date: string
  reason: string
  performedBy: string
  notes?: string
}

// Report Types
export interface Report {
  id: string
  title: string
  type: "patient_statistics" | "financial" | "inventory" | "staff" | "quality"
  generatedBy: string
  generatedAt: string
  period?: {
    startDate: string
    endDate: string
  }
  data: any
  status: "generating" | "completed" | "failed"
}

// Dashboard Types
export interface DashboardMetrics {
  totalPatients: number
  activeAppointments: number
  availableBeds: number
  totalBeds: number
  occupancyRate: number
  totalStaff: number
  onDutyStaff: number
  pendingLabResults: number
  criticalAlerts: number
  revenue: {
    today: number
    thisMonth: number
    lastMonth: number
    growth: number
  }
  appointments: {
    today: number
    thisWeek: number
    nextWeek: number
  }
  departments: {
    name: string
    patients: number
    occupancy: number
    revenue: number
  }[]
  alerts: {
    id: string
    type: "critical" | "warning" | "info"
    message: string
    timestamp: string
  }[]
}

// System Settings Types
export interface SystemSettings {
  hospitalInfo: {
    name: string
    address: string
    phone: string
    email: string
    website: string
    logo: string
  }
  operatingHours: {
    weekdays: { open: string; close: string }
    weekends: { open: string; close: string }
    emergency: string
  }
  appointments: {
    slotDuration: number
    advanceBookingDays: number
    cancellationHours: number
    reminderHours: number
  }
  billing: {
    currency: string
    taxRate: number
    paymentTerms: number
    lateFeePenalty: number
  }
  notifications: {
    emailEnabled: boolean
    smsEnabled: boolean
    pushEnabled: boolean
    reminderTypes: string[]
  }
  security: {
    sessionTimeout: number
    passwordMinLength: number
    requireTwoFactor: boolean
    maxLoginAttempts: number
  }
}

// Audit Log Types
export interface AuditLog {
  id: string
  userId: string
  action: string
  resourceType: string
  resourceId: string
  timestamp: string
  ipAddress: string
  userAgent: string
  details?: any
}
