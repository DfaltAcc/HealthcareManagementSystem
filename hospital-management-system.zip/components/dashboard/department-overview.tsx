import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import type { DashboardMetrics } from "@/types"

interface DepartmentOverviewProps {
  metrics: DashboardMetrics
}

export function DepartmentOverview({ metrics }: DepartmentOverviewProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Department Overview</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {metrics.departments.map((dept, index) => (
            <div key={index} className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium text-gray-900">{dept.name}</h4>
                <span className="text-sm text-gray-500">{dept.patients} patients</span>
              </div>

              <Progress value={dept.occupancy * 100} className="h-2" />

              <div className="flex items-center justify-between text-xs text-gray-500">
                <span>Occupancy: {(dept.occupancy * 100).toFixed(1)}%</span>
                <span>Revenue: ${dept.revenue.toLocaleString()}</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
