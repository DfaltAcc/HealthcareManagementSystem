import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import type { Appointment, Patient, Doctor } from "@/types"
import { Clock, MapPin } from "lucide-react"

interface RecentAppointmentsProps {
  appointments: Appointment[]
  patients: Patient[]
  doctors: Doctor[]
}

export function RecentAppointments({ appointments, patients, doctors }: RecentAppointmentsProps) {
  const getPatient = (patientId: string) => patients.find((p) => p.id === patientId)
  const getDoctor = (doctorId: string) => doctors.find((d) => d.id === doctorId)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority?: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Appointments</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {appointments.slice(0, 5).map((appointment) => {
            const patient = getPatient(appointment.patientId)
            const doctor = getDoctor(appointment.doctorId)

            return (
              <div key={appointment.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                <Avatar>
                  <AvatarImage
                    src={`/placeholder.svg?height=40&width=40&query=${patient?.firstName} ${patient?.lastName}`}
                  />
                  <AvatarFallback>
                    {patient?.firstName?.[0]}
                    {patient?.lastName?.[0]}
                  </AvatarFallback>
                </Avatar>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {patient?.firstName} {patient?.lastName}
                    </p>
                    <Badge className={getStatusColor(appointment.status)}>{appointment.status}</Badge>
                  </div>

                  <div className="flex items-center space-x-4 mt-1">
                    <p className="text-sm text-gray-500">
                      Dr. {doctor?.firstName} {doctor?.lastName}
                    </p>
                    {appointment.priority && (
                      <Badge variant="outline" className={getPriorityColor(appointment.priority)}>
                        {appointment.priority}
                      </Badge>
                    )}
                  </div>

                  <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                    <div className="flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {appointment.date} at {appointment.startTime}
                    </div>
                    {appointment.roomNumber && (
                      <div className="flex items-center">
                        <MapPin className="h-3 w-3 mr-1" />
                        Room {appointment.roomNumber}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
