"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { QrCode, Shield, Copy, Check, Download } from "lucide-react"
import { generate2FASecret, generate2FAQRCode, verify2FAToken, generateBackupCodes } from "@/lib/2fa"

interface TwoFactorSetupProps {
  userEmail: string
  onSetupComplete: (secret: string, backupCodes: string[]) => void
}

export function TwoFactorSetup({ userEmail, onSetupComplete }: TwoFactorSetupProps) {
  const [secret, setSecret] = useState("")
  const [qrCodeUrl, setQrCodeUrl] = useState("")
  const [verificationCode, setVerificationCode] = useState("")
  const [backupCodes, setBackupCodes] = useState<string[]>([])
  const [step, setStep] = useState(1)
  const [error, setError] = useState("")
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    // Generate secret and QR code
    const newSecret = generate2FASecret(userEmail)
    const qrUrl = generate2FAQRCode(userEmail, newSecret)
    setSecret(newSecret)
    setQrCodeUrl(qrUrl)
  }, [userEmail])

  const handleVerification = () => {
    if (!verificationCode) {
      setError("Please enter the verification code")
      return
    }

    const isValid = verify2FAToken(verificationCode, secret)
    if (!isValid) {
      setError("Invalid verification code. Please try again.")
      return
    }

    // Generate backup codes
    const codes = generateBackupCodes()
    setBackupCodes(codes)
    setStep(2)
    setError("")
  }

  const handleComplete = () => {
    onSetupComplete(secret, backupCodes)
  }

  const copySecret = async () => {
    await navigator.clipboard.writeText(secret)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const downloadBackupCodes = () => {
    const content = `Hospital Management System - Backup Codes\n\nGenerated: ${new Date().toLocaleString()}\nEmail: ${userEmail}\n\nBackup Codes:\n${backupCodes.join("\n")}\n\nKeep these codes safe and secure. Each code can only be used once.`
    const blob = new Blob([content], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "hospital-2fa-backup-codes.txt"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Two-Factor Authentication Setup
        </CardTitle>
        <CardDescription>{step === 1 ? "Secure your account with 2FA" : "Save your backup codes"}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {step === 1 && (
          <>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">Step 1: Scan QR Code</h4>
                <p className="text-sm text-gray-600 mb-4">
                  Scan this QR code with your authenticator app (Google Authenticator, Authy, etc.)
                </p>

                {/* QR Code placeholder - in a real app, you'd use a QR code library */}
                <div className="flex justify-center p-4 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
                  <div className="text-center">
                    <QrCode className="h-32 w-32 mx-auto text-gray-400 mb-2" />
                    <p className="text-xs text-gray-500">QR Code for: {userEmail}</p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Manual Entry</h4>
                <p className="text-sm text-gray-600 mb-2">If you can't scan the QR code, enter this secret manually:</p>
                <div className="flex items-center gap-2">
                  <Input value={secret} readOnly className="font-mono text-xs" />
                  <Button variant="outline" size="sm" onClick={copySecret} className="shrink-0 bg-transparent">
                    {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-2">Step 2: Verify Setup</h4>
                <Label htmlFor="verificationCode">Enter the 6-digit code from your app</Label>
                <Input
                  id="verificationCode"
                  type="text"
                  placeholder="000000"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value)}
                  maxLength={6}
                  className="font-mono text-center text-lg"
                />
              </div>

              <Button onClick={handleVerification} className="w-full">
                Verify & Continue
              </Button>
            </div>
          </>
        )}

        {step === 2 && (
          <>
            <div className="space-y-4">
              <Alert>
                <Shield className="h-4 w-4" />
                <AlertDescription>
                  Two-factor authentication has been successfully enabled for your account!
                </AlertDescription>
              </Alert>

              <div>
                <h4 className="font-medium mb-2">Backup Codes</h4>
                <p className="text-sm text-gray-600 mb-4">
                  Save these backup codes in a safe place. You can use them to access your account if you lose your
                  authenticator device.
                </p>

                <div className="grid grid-cols-2 gap-2 p-4 bg-gray-50 rounded-lg">
                  {backupCodes.map((code, index) => (
                    <Badge key={index} variant="secondary" className="font-mono justify-center">
                      {code}
                    </Badge>
                  ))}
                </div>

                <div className="flex gap-2 mt-4">
                  <Button variant="outline" onClick={downloadBackupCodes} className="flex-1 bg-transparent">
                    <Download className="h-4 w-4 mr-2" />
                    Download Codes
                  </Button>
                </div>
              </div>

              <Alert>
                <AlertDescription className="text-xs">
                  <strong>Important:</strong> Each backup code can only be used once. Store them securely and don't
                  share them with anyone.
                </AlertDescription>
              </Alert>

              <Button onClick={handleComplete} className="w-full">
                Complete Setup
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
