"use client"

import type React from "react"

import { useState } from "react"
import { signIn, getSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Eye, EyeOff, Mail, Lock, Shield, Loader2 } from "lucide-react"

export function LoginForm() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    code: "",
  })
  const [showPassword, setShowPassword] = useState(false)
  const [showTwoFactor, setShowTwoFactor] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    setError("") // Clear error when user types
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      console.log("🚀 Starting login process...")

      const result = await signIn("credentials", {
        email: formData.email,
        password: formData.password,
        code: formData.code || undefined,
        redirect: false,
      })

      console.log("📋 SignIn result:", result)

      if (result?.error) {
        console.error("❌ Login failed:", result.error)
        setError("Invalid email or password. Please try again.")
      } else if (result?.ok) {
        console.log("✅ Login successful!")

        // Verify session was created
        const session = await getSession()
        console.log("📋 Session created:", session)

        if (session) {
          router.push("/")
          router.refresh()
        } else {
          setError("Session creation failed. Please try again.")
        }
      } else {
        setError("Login failed. Please try again.")
      }
    } catch (error) {
      console.error("🚨 Login error:", error)
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const fillDemoCredentials = (type: "admin" | "doctor" | "nurse") => {
    const credentials = {
      admin: { email: "admin@hospital.com", password: "password123" },
      doctor: { email: "doctor@hospital.com", password: "password123" },
      nurse: { email: "nurse@hospital.com", password: "password123" },
    }

    setFormData((prev) => ({
      ...prev,
      email: credentials[type].email,
      password: credentials[type].password,
    }))
    setError("")
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold text-center">Sign In</CardTitle>
        <CardDescription className="text-center">Access your hospital management account</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                className="pl-10"
                required
                disabled={isLoading}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                placeholder="Enter your password"
                value={formData.password}
                onChange={(e) => handleInputChange("password", e.target.value)}
                className="pl-10 pr-10"
                required
                disabled={isLoading}
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                onClick={() => setShowPassword(!showPassword)}
                disabled={isLoading}
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4 text-gray-400" />
                ) : (
                  <Eye className="h-4 w-4 text-gray-400" />
                )}
              </Button>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="enable2fa"
              checked={showTwoFactor}
              onChange={(e) => setShowTwoFactor(e.target.checked)}
              className="rounded"
              disabled={isLoading}
            />
            <Label htmlFor="enable2fa" className="text-sm">
              Enable Two-Factor Authentication
            </Label>
          </div>

          {showTwoFactor && (
            <div className="space-y-2">
              <Label htmlFor="code">Two-Factor Authentication Code</Label>
              <div className="relative">
                <Shield className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="code"
                  type="text"
                  placeholder="Enter 6-digit code (123456)"
                  value={formData.code}
                  onChange={(e) => handleInputChange("code", e.target.value)}
                  className="pl-10"
                  maxLength={6}
                  disabled={isLoading}
                />
              </div>
              <p className="text-xs text-gray-500">Use 123456 for demo purposes</p>
            </div>
          )}

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Signing in...
              </>
            ) : (
              "Sign In"
            )}
          </Button>
        </form>

        {/* Demo Credentials */}
        <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <h4 className="text-sm font-medium text-blue-900 mb-3">Demo Accounts</h4>
          <div className="grid gap-2">
            {[
              { type: "admin" as const, name: "Admin User", email: "admin@hospital.com" },
              { type: "doctor" as const, name: "Dr. Sarah Johnson", email: "doctor@hospital.com" },
              { type: "nurse" as const, name: "Nurse Robert Chen", email: "nurse@hospital.com" },
            ].map(({ type, name, email }) => (
              <Button
                key={type}
                type="button"
                variant="outline"
                size="sm"
                className="w-full bg-transparent text-left justify-start"
                onClick={() => fillDemoCredentials(type)}
                disabled={isLoading}
              >
                <div className="text-left">
                  <div className="font-medium">{name}</div>
                  <div className="text-xs text-gray-600">{email}</div>
                </div>
              </Button>
            ))}
          </div>
          <div className="mt-3 text-xs text-blue-800">
            <p>
              <strong>Password:</strong> password123 (for all accounts)
            </p>
            <p>
              <strong>2FA Code:</strong> 123456 (optional)
            </p>
          </div>
        </div>

        <div className="text-center text-sm text-gray-500">
          <p>Don't have an account? Contact your administrator</p>
        </div>
      </CardContent>
    </Card>
  )
}
