"use client"

import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { ConditionalLayout } from "@/components/layout/conditional-layout"
import { StatsCards } from "@/components/dashboard/stats-cards"
import { RecentAppointments } from "@/components/dashboard/recent-appointments"
import { DepartmentOverview } from "@/components/dashboard/department-overview"
import { AlertsPanel } from "@/components/dashboard/alerts-panel"
import { dashboardMetrics, appointments, patients, doctors } from "@/lib/mock-data"
import { Loader2 } from "lucide-react"

export default function DashboardPage() {
  const { data: session, status } = useSession()
  const router = useRouter()

  useEffect(() => {
    console.log("📋 Dashboard - Session status:", status)
    console.log("👤 Dashboard - Session data:", session)

    if (status === "loading") return

    if (!session) {
      console.log("❌ No session found, redirecting to signin")
      router.push("/auth/signin")
    } else {
      console.log("✅ Session found, user:", session.user?.email)
    }
  }, [session, status, router])

  if (status === "loading") {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  if (!session) {
    return null
  }

  return (
    <ConditionalLayout>
      <div className="space-y-6">
        {/* Page Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-2">
            Welcome back, {session.user.name}! Here's what's happening at your hospital today.
          </p>
          <div className="mt-2 text-sm text-gray-500">
            Role: <span className="font-medium">{(session.user as any)?.role || "Unknown"}</span>
          </div>
        </div>

        {/* Stats Cards */}
        <StatsCards metrics={dashboardMetrics} />

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Appointments - Takes 2 columns */}
          <div className="lg:col-span-2">
            <RecentAppointments appointments={appointments} patients={patients} doctors={doctors} />
          </div>

          {/* Alerts Panel */}
          <div>
            <AlertsPanel metrics={dashboardMetrics} />
          </div>
        </div>

        {/* Department Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <DepartmentOverview metrics={dashboardMetrics} />

          {/* Revenue Chart Placeholder */}
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue Trends</h3>
            <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
              <p className="text-gray-500">Revenue chart would go here</p>
            </div>
          </div>
        </div>
      </div>
    </ConditionalLayout>
  )
}
