import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    console.log("🔐 API: Validating credentials")

    const { email, password, code } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 })
    }

    // Mock validation logic
    const mockUsers = [
      { email: "admin@hospital.com", password: "password123", role: "admin" },
      { email: "doctor@hospital.com", password: "password123", role: "doctor" },
      { email: "nurse@hospital.com", password: "password123", role: "nurse" },
    ]

    const user = mockUsers.find((u) => u.email === email)

    if (!user || user.password !== password) {
      console.log("❌ API: Invalid credentials")
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    // Check 2FA if provided
    if (code && code !== "123456") {
      console.log("❌ API: Invalid 2FA code")
      return NextResponse.json({ error: "Invalid 2FA code" }, { status: 401 })
    }

    console.log("✅ API: Credentials validated successfully")

    return NextResponse.json({
      success: true,
      user: {
        email: user.email,
        role: user.role,
      },
    })
  } catch (error) {
    console.error("🚨 API Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
