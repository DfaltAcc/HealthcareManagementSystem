import NextAuth from "next-auth"
import type { NextAuthOptions } from "next-auth"

// Mock users database
const users = [
  {
    id: "1",
    email: "admin@hospital.com",
    name: "Admin User",
    role: "admin",
    password: "password123",
  },
  {
    id: "2",
    email: "doctor@hospital.com",
    name: "Dr. Sarah Johnson",
    role: "doctor",
    password: "password123",
  },
  {
    id: "3",
    email: "nurse@hospital.com",
    name: "Nurse Robert Chen",
    role: "nurse",
    password: "password123",
  },
]

export const authOptions: NextAuthOptions = {
  providers: [
    {
      id: "credentials",
      name: "credentials",
      type: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
        code: { label: "2FA Code", type: "text", required: false },
      },
      authorize: async (credentials) => {
        console.log("🔐 Authorize called with:", credentials?.email)

        if (!credentials?.email || !credentials?.password) {
          console.log("❌ Missing credentials")
          return null
        }

        // Find user
        const user = users.find((u) => u.email === credentials.email)
        if (!user) {
          console.log("❌ User not found")
          return null
        }

        // Check password
        if (user.password !== credentials.password) {
          console.log("❌ Invalid password")
          return null
        }

        // Check 2FA if provided
        if (credentials.code && credentials.code !== "123456") {
          console.log("❌ Invalid 2FA code")
          return null
        }

        console.log("✅ User authenticated:", user.email)

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
        }
      },
    },
  ],
  callbacks: {
    jwt: async ({ token, user }) => {
      if (user) {
        token.role = (user as any).role
      }
      return token
    },
    session: async ({ session, token }) => {
      if (session.user) {
        ;(session.user as any).role = token.role(session.user as any).id = token.sub
      }
      return session
    },
  },
  pages: {
    signIn: "/auth/signin",
    error: "/auth/error",
  },
  session: {
    strategy: "jwt",
  },
  secret: process.env.NEXTAUTH_SECRET || "development-secret-key",
}

const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }
