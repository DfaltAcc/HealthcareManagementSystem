import { type NextRequest, NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "../[...nextauth]/route"

// Mock user data
const mockUsers = [
  {
    id: "1",
    email: "admin@hospital.com",
    name: "Admin User",
    role: "admin",
    department: "Administration",
    phone: "+1 (555) 123-4567",
    avatar: "/placeholder.svg?height=150&width=150",
    lastLogin: "2025-01-29T10:30:00Z",
    permissions: ["read", "write", "delete", "admin"],
  },
  {
    id: "2",
    email: "doctor@hospital.com",
    name: "Dr. Sarah Johnson",
    role: "doctor",
    department: "Cardiology",
    phone: "+1 (555) 234-5678",
    avatar: "/placeholder.svg?height=150&width=150",
    lastLogin: "2025-01-29T09:15:00Z",
    permissions: ["read", "write"],
  },
  {
    id: "3",
    email: "nurse@hospital.com",
    name: "Nurse Robert Chen",
    role: "nurse",
    department: "General Medicine",
    phone: "+1 (555) 345-6789",
    avatar: "/placeholder.svg?height=150&width=150",
    lastLogin: "2025-01-29T08:45:00Z",
    permissions: ["read"],
  },
]

export async function GET(request: NextRequest) {
  try {
    console.log("🔍 API: Getting user profile")

    // Get session from NextAuth
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      console.log("❌ API: No session found")
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Find user in mock data
    const user = mockUsers.find((u) => u.email === session.user.email)

    if (!user) {
      console.log("❌ API: User not found")
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    console.log("✅ API: User profile retrieved successfully")

    return NextResponse.json({
      success: true,
      user: user,
    })
  } catch (error) {
    console.error("🚨 API Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    console.log("📝 API: Updating user profile")

    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    console.log("📝 API: Update data:", body)

    return NextResponse.json({
      success: true,
      message: "Profile updated successfully",
    })
  } catch (error) {
    console.error("🚨 API Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
