"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, Plus, Eye, Edit, Phone, Mail, Clock, DollarSign } from "lucide-react"
import { doctors, users } from "@/lib/mock-data"

export default function DoctorsPage() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredDoctors = doctors.filter(
    (doctor) =>
      `${doctor.firstName} ${doctor.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doctor.specialization.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doctor.department.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getDoctorUser = (userId: string) => users.find((u) => u.id === userId)

  const getSpecializationColor = (specialization: string) => {
    const colors: { [key: string]: string } = {
      Cardiology: "bg-red-100 text-red-800",
      Neurology: "bg-purple-100 text-purple-800",
      Pediatrics: "bg-green-100 text-green-800",
      Orthopedics: "bg-blue-100 text-blue-800",
      Dermatology: "bg-yellow-100 text-yellow-800",
    }
    return colors[specialization] || "bg-gray-100 text-gray-800"
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Doctors</h1>
          <p className="text-gray-600 mt-2">Manage doctor profiles and schedules</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Add Doctor
        </Button>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Medical Staff Directory</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4 mb-6">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                type="search"
                placeholder="Search doctors by name, specialization, or department..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline">Filter by Department</Button>
            <Button variant="outline">Export</Button>
          </div>

          {/* Doctors Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Doctor</TableHead>
                  <TableHead>Specialization</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Experience</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Consultation Fee</TableHead>
                  <TableHead>Availability</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDoctors.map((doctor) => {
                  const user = getDoctorUser(doctor.userId)
                  return (
                    <TableRow key={doctor.id}>
                      <TableCell>
                        <div className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarImage src={user?.avatar || "/placeholder.svg"} />
                            <AvatarFallback>
                              {doctor.firstName[0]}
                              {doctor.lastName[0]}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium text-gray-900">
                              Dr. {doctor.firstName} {doctor.lastName}
                            </p>
                            <p className="text-sm text-gray-500">License: {doctor.licenseNumber}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getSpecializationColor(doctor.specialization)}>{doctor.specialization}</Badge>
                      </TableCell>
                      <TableCell>
                        <span className="text-sm font-medium">{doctor.department}</span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center text-sm">
                          <Clock className="h-3 w-3 mr-1 text-gray-400" />
                          {doctor.experience} years
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center text-sm">
                            <Phone className="h-3 w-3 mr-1 text-gray-400" />
                            {doctor.contactNumber}
                          </div>
                          <div className="flex items-center text-sm text-gray-500">
                            <Mail className="h-3 w-3 mr-1 text-gray-400" />
                            {doctor.email}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center text-sm font-medium">
                          <DollarSign className="h-3 w-3 mr-1 text-green-600" />${doctor.consultationFee}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {doctor.availability.slice(0, 2).map((slot, index) => (
                            <div key={index} className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                              {slot.day}: {slot.startTime}-{slot.endTime}
                            </div>
                          ))}
                          {doctor.availability.length > 2 && (
                            <div className="text-xs text-gray-500">+{doctor.availability.length - 2} more</div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between mt-4">
            <p className="text-sm text-gray-500">
              Showing {filteredDoctors.length} of {doctors.length} doctors
            </p>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" disabled>
                Previous
              </Button>
              <Button variant="outline" size="sm" disabled>
                Next
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
