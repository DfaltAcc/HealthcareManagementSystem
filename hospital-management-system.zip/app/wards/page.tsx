"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, Plus, Bed, Phone, Users, Building } from "lucide-react"
import { wards } from "@/lib/mock-data"

export default function WardsPage() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredWards = wards.filter(
    (ward) =>
      ward.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ward.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ward.headNurse.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getWardTypeColor = (type: string) => {
    switch (type) {
      case "icu":
        return "bg-red-100 text-red-800"
      case "emergency":
        return "bg-orange-100 text-orange-800"
      case "maternity":
        return "bg-pink-100 text-pink-800"
      case "pediatric":
        return "bg-blue-100 text-blue-800"
      case "general":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getOccupancyColor = (occupancyRate: number) => {
    if (occupancyRate >= 0.9) return "text-red-600"
    if (occupancyRate >= 0.7) return "text-yellow-600"
    return "text-green-600"
  }

  const calculateOccupancyRate = (ward: (typeof wards)[0]) => {
    return ((ward.totalBeds - ward.availableBeds) / ward.totalBeds) * 100
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Wards</h1>
          <p className="text-gray-600 mt-2">Manage hospital wards and bed allocation</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Add Ward
        </Button>
      </div>

      {/* Ward Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Wards</p>
                <p className="text-2xl font-bold text-gray-900">{wards.length}</p>
              </div>
              <Building className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Beds</p>
                <p className="text-2xl font-bold text-gray-900">
                  {wards.reduce((sum, ward) => sum + ward.totalBeds, 0)}
                </p>
              </div>
              <Bed className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Available Beds</p>
                <p className="text-2xl font-bold text-gray-900">
                  {wards.reduce((sum, ward) => sum + ward.availableBeds, 0)}
                </p>
              </div>
              <Bed className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Occupancy Rate</p>
                <p className="text-2xl font-bold text-gray-900">
                  {(
                    ((wards.reduce((sum, ward) => sum + ward.totalBeds, 0) -
                      wards.reduce((sum, ward) => sum + ward.availableBeds, 0)) /
                      wards.reduce((sum, ward) => sum + ward.totalBeds, 0)) *
                    100
                  ).toFixed(1)}
                  %
                </p>
              </div>
              <Users className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Wards Management */}
      <Card>
        <CardHeader>
          <CardTitle>Ward Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4 mb-6">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                type="search"
                placeholder="Search wards by name, type, or head nurse..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline">Filter by Type</Button>
            <Button variant="outline">Export</Button>
          </div>

          {/* Wards Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Ward</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Floor</TableHead>
                  <TableHead>Bed Capacity</TableHead>
                  <TableHead>Occupancy</TableHead>
                  <TableHead>Head Nurse</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredWards.map((ward) => {
                  const occupancyRate = calculateOccupancyRate(ward)
                  const occupiedBeds = ward.totalBeds - ward.availableBeds

                  return (
                    <TableRow key={ward.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium text-gray-900">{ward.name}</p>
                          <p className="text-sm text-gray-500">ID: {ward.id}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getWardTypeColor(ward.type)}>{ward.type.toUpperCase()}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Building className="h-4 w-4 mr-2 text-gray-400" />
                          Floor {ward.floorNumber}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center justify-between text-sm">
                            <span>Total: {ward.totalBeds}</span>
                            <span className="text-green-600">Available: {ward.availableBeds}</span>
                          </div>
                          <div className="text-xs text-gray-500">Occupied: {occupiedBeds}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className={`text-sm font-medium ${getOccupancyColor(occupancyRate / 100)}`}>
                              {occupancyRate.toFixed(1)}%
                            </span>
                          </div>
                          <Progress value={occupancyRate} className="h-2" />
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Users className="h-4 w-4 mr-2 text-gray-400" />
                          <span className="text-sm">{ward.headNurse}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Phone className="h-4 w-4 mr-2 text-gray-400" />
                          <span className="text-sm">{ward.contactNumber}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm">
                            View
                          </Button>
                          <Button variant="ghost" size="sm">
                            Edit
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between mt-4">
            <p className="text-sm text-gray-500">
              Showing {filteredWards.length} of {wards.length} wards
            </p>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" disabled>
                Previous
              </Button>
              <Button variant="outline" size="sm" disabled>
                Next
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
