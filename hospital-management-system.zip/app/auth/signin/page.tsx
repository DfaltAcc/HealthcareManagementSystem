import { LoginForm } from "@/components/auth/login-form"
import { Building2 } from "lucide-react"

export default function SignInPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="w-full max-w-md">
        {/* Hospital Logo/Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-blue-600 p-3 rounded-full">
              <Building2 className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-gray-900">MediCare HMS</h1>
          <p className="text-gray-600 mt-2">Hospital Management System</p>
        </div>

        <LoginForm />

        {/* Footer */}
        <div className="text-center mt-8 text-sm text-gray-500">
          <p>&copy; 2025 MediCare Hospital. All rights reserved.</p>
          <p className="mt-1">
            <a href="#" className="hover:text-gray-700">
              Privacy Policy
            </a>
            {" • "}
            <a href="#" className="hover:text-gray-700">
              Terms of Service
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}
