"use client"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { TwoFactorSetup } from "@/components/auth/two-factor-setup"

export default function Setup2FAPage() {
  const { data: session } = useSession()
  const router = useRouter()

  const handleSetupComplete = (secret: string, backupCodes: string[]) => {
    // In a real app, you'd save the secret to the user's profile
    console.log("2FA Setup completed:", { secret, backupCodes })

    // Redirect to dashboard
    router.push("/")
  }

  if (!session) {
    return null
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <TwoFactorSetup userEmail={session?.user?.email || ""} onSetupComplete={handleSetupComplete} />
    </div>
  )
}
